# 1-amaliy-ish
